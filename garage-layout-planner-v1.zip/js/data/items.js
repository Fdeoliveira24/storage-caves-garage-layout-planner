/**
 * Item Library
 * Pre-defined items with realistic dimensions (all VERTICAL by default)
 * lengthFt = height (vertical), widthFt = width (horizontal)
 */
const Items = {
  categories: {
    vehicles: {
      name: 'Vehicles',
      items: [
        {
          id: 'sports-car',
          label: 'Sports Car',
          lengthFt: 15,
          widthFt: 6,
          color: '#E57373',
          category: 'vehicles',
          paletteImage: 'assets/images/items/palette/sports-car-side.png',
          canvasImage: 'assets/images/items/canvas/sports-car-top.png',
        },
        {
          id: 'sedan',
          label: 'Sedan',
          lengthFt: 16,
          widthFt: 6,
          color: '#64B5F6',
          category: 'vehicles',
          paletteImage: 'assets/images/items/palette/sedan-side.png',
          canvasImage: 'assets/images/items/canvas/sedan-top.png',
        },
        {
          id: 'pickup',
          label: 'Pickup Truck',
          lengthFt: 19,
          widthFt: 6.5,
          color: '#81C784',
          category: 'vehicles',
          paletteImage: 'assets/images/items/palette/pickup-side.png',
          canvasImage: 'assets/images/items/canvas/pickup-top.png',
        },
        {
          id: 'suv',
          label: 'SUV',
          lengthFt: 17,
          widthFt: 6.5,
          color: '#BA68C8',
          category: 'vehicles',
          paletteImage: 'assets/images/items/palette/suv-side.png',
          canvasImage: 'assets/images/items/canvas/suv-top.png',
        },
        {
          id: 'motorcycle',
          label: 'Motorcycle',
          lengthFt: 7,
          widthFt: 3,
          color: '#FFB74D',
          category: 'vehicles',
          paletteImage: 'assets/images/items/palette/motorcycle-side.png',
          canvasImage: 'assets/images/items/canvas/motorcycle-top.png',
        },
        {
          id: 'van',
          label: 'Van',
          lengthFt: 18,
          widthFt: 6.5,
          color: '#A1887F',
          category: 'vehicles',
          paletteImage: 'assets/images/items/palette/van-side.png',
          canvasImage: 'assets/images/items/canvas/van-top.png',
        },
      ],
    },
    recreational: {
      name: 'Recreational Vehicles',
      items: [
        {
          id: 'boat-trailer',
          label: 'Boat with Trailer',
          lengthFt: 20,
          widthFt: 7,
          color: '#4DD0E1',
          category: 'recreational',
          paletteImage: 'assets/images/items/palette/boat-trailer-side.png',
          canvasImage: 'assets/images/items/canvas/boat-trailer-top.png',
        },
        {
          id: 'rv-26',
          label: 'RV (26 ft)',
          lengthFt: 26,
          widthFt: 8,
          color: '#AED581',
          category: 'recreational',
          paletteImage: 'assets/images/items/palette/rv-26-side.png',
          canvasImage: 'assets/images/items/canvas/rv-26-top.png',
        },
        {
          id: 'rv-34',
          label: 'RV (34 ft)',
          lengthFt: 34,
          widthFt: 8.5,
          color: '#DCE775',
          category: 'recreational',
          paletteImage: 'assets/images/items/palette/rv-34-side.png',
          canvasImage: 'assets/images/items/canvas/rv-34-top.png',
        },
        {
          id: 'jet-ski-trailer',
          label: 'Jet Ski with Trailer',
          lengthFt: 12,
          widthFt: 5,
          color: '#4FC3F7',
          category: 'recreational',
          paletteImage: 'assets/images/items/palette/jet-ski-trailer-side.png',
          canvasImage: 'assets/images/items/canvas/jet-ski-trailer-top.png',
        },
        {
          id: 'atv',
          label: 'ATV',
          lengthFt: 7,
          widthFt: 4,
          color: '#FFD54F',
          category: 'recreational',
          paletteImage: 'assets/images/items/palette/atv-side.png',
          canvasImage: 'assets/images/items/canvas/atv-top.png',
        },
        {
          id: 'golf-cart',
          label: 'Golf Cart',
          lengthFt: 8,
          widthFt: 4,
          color: '#90CAF9',
          category: 'recreational',
          paletteImage: 'assets/images/items/palette/golf-cart-side.png',
          canvasImage: 'assets/images/items/canvas/golf-cart-top.png',
        },
      ],
    },
    storage: {
      name: 'Storage & Furniture',
      items: [
        {
          id: 'shelf',
          label: 'Storage Shelf',
          lengthFt: 4,
          widthFt: 2,
          color: '#90A4AE',
          category: 'storage',
          paletteImage: 'assets/images/items/palette/shelf-side.png',
          canvasImage: 'assets/images/items/canvas/shelf-top.png',
        },
        {
          id: 'workbench',
          label: 'Workbench',
          lengthFt: 6,
          widthFt: 2.5,
          color: '#8D6E63',
          category: 'storage',
          paletteImage: 'assets/images/items/palette/workbench-side.png',
          canvasImage: 'assets/images/items/canvas/workbench-top.png',
        },
        {
          id: 'storage-box',
          label: 'Storage Box',
          lengthFt: 3,
          widthFt: 3,
          color: '#B0BEC5',
          category: 'storage',
          paletteImage: 'assets/images/items/palette/storage-box-side.png',
          canvasImage: 'assets/images/items/canvas/storage-box-top.png',
        },
        {
          id: 'tool-cabinet',
          label: 'Tool Cabinet',
          lengthFt: 5,
          widthFt: 2,
          color: '#EF5350',
          category: 'storage',
          paletteImage: 'assets/images/items/palette/tool-cabinet-side.png',
          canvasImage: 'assets/images/items/canvas/tool-cabinet-top.png',
        },
        {
          id: 'bike-rack',
          label: 'Bike Rack',
          lengthFt: 6,
          widthFt: 2,
          color: '#42A5F5',
          category: 'storage',
          paletteImage: 'assets/images/items/palette/bike-rack-side.png',
          canvasImage: 'assets/images/items/canvas/bike-rack-top.png',
        },
        {
          id: 'freezer',
          label: 'Chest Freezer',
          lengthFt: 5,
          widthFt: 2.5,
          color: '#ECEFF1',
          category: 'storage',
          paletteImage: 'assets/images/items/palette/freezer-side.png',
          canvasImage: 'assets/images/items/canvas/freezer-top.png',
        },
        {
          id: 'scaffold-rack',
          label: 'Scaffold Rack',
          lengthFt: 8,
          widthFt: 1.5,
          color: '#FFA726',
          category: 'storage',
          paletteImage: 'assets/images/items/palette/scaffold-side.png',
          canvasImage: 'assets/images/items/canvas/scaffold-top.png',
        },
        {
          id: 'kayak',
          label: 'Kayak',
          lengthFt: 12,
          widthFt: 2.8,
          color: '#A1887F',
          category: 'storage',
          paletteImage: 'assets/images/items/palette/kayak-side.png',
          canvasImage: 'assets/images/items/canvas/kayak-top.png',
        },
        {
          id: 'small-tool-box',
          label: 'Tool Box',
          lengthFt: 3,
          widthFt: 1.5,
          color: '#90A4AE',
          category: 'storage',
          paletteImage: 'assets/images/items/palette/small-tool-box-side.png',
          canvasImage: 'assets/images/items/canvas/small-tool-box-top.png',
        },
        {
          id: 'car-lift',
          label: 'Car Lift',
          lengthFt: 15,
          widthFt: 9,
          color: '#EF5350',
          category: 'storage',
          paletteImage: 'assets/images/items/palette/car-lift-side.png',
          canvasImage: 'assets/images/items/canvas/car-lift-top.png',
        },
        {
          id: 'pool-table',
          label: 'Pool Table',
          lengthFt: 9,
          widthFt: 5,
          color: '#10B981',
          category: 'storage',
          paletteImage: 'assets/images/items/palette/pool-table-side.png',
          canvasImage: 'assets/images/items/canvas/pool-table-top.png',
        },
        {
          id: 'sofa',
          label: 'Couch',
          lengthFt: 8,
          widthFt: 3,
          color: '#8B5CF6',
          category: 'storage',
          paletteImage: 'assets/images/items/palette/sofa-side.png',
          canvasImage: 'assets/images/items/canvas/sofa-top.png',
        },
      ],
    },
    mezzanine: {
      name: 'Mezzanine Options',
      items: [
        {
          id: 'mezzanine-option-1',
          label: 'Mezzanine Option 1',
          lengthFt: 14,
          widthFt: 11,
          color: '#9CA3AF',
          category: 'mezzanine',
          paletteImage: null,
          canvasImage: null,
        },
        {
          id: 'mezzanine-option-2',
          label: 'Mezzanine Option 2',
          lengthFt: 16,
          widthFt: 15,
          color: '#9CA3AF',
          category: 'mezzanine',
          paletteImage: null,
          canvasImage: null,
        },
        {
          id: 'mezzanine-option-3',
          label: 'Mezzanine Option 3',
          lengthFt: 17,
          widthFt: 14,
          color: '#9CA3AF',
          category: 'mezzanine',
          paletteImage: null,
          canvasImage: null,
        },
        {
          id: 'mezzanine-option-4',
          label: 'Mezzanine Option 4',
          lengthFt: 18,
          widthFt: 16,
          color: '#9CA3AF',
          category: 'mezzanine',
          paletteImage: null,
          canvasImage: null,
        },
        {
          id: 'mezzanine-option-5',
          label: 'Mezzanine Option 5',
          lengthFt: 22,
          widthFt: 18,
          color: '#9CA3AF',
          category: 'mezzanine',
          paletteImage: null,
          canvasImage: null,
        },
      ],
    },
    shapes: {
      name: '2D Shapes',
      items: [
        {
          id: 'shape-square',
          label: 'Square',
          lengthFt: 10,
          widthFt: 10,
          color: '#F97316',
          category: 'shapes',
          shapeType: 'square',
          paletteImage: null,
          canvasImage: null,
        },
        {
          id: 'shape-circle',
          label: 'Circle',
          lengthFt: 10,
          widthFt: 10,
          color: '#0EA5E9',
          category: 'shapes',
          shapeType: 'circle',
          paletteImage: null,
          canvasImage: null,
        },
        {
          id: 'shape-rectangle',
          label: 'Rectangle',
          lengthFt: 12,
          widthFt: 6,
          color: '#6366F1',
          category: 'shapes',
          shapeType: 'rectangle',
          paletteImage: null,
          canvasImage: null,
        },
        {
          id: 'shape-triangle',
          label: 'Triangle',
          lengthFt: 9,
          widthFt: 8,
          color: '#10B981',
          category: 'shapes',
          shapeType: 'triangle',
          paletteImage: null,
          canvasImage: null,
        },
      ],
    },
  },

  /**
   * Get all items
   */
  getAll() {
    const allItems = [];
    for (const category in this.categories) {
      allItems.push(...this.categories[category].items);
    }
    return allItems;
  },

  /**
   * Get item by ID
   */
  getById(id) {
    return this.getAll().find((item) => item.id === id);
  },

  /**
   * Get items by category
   */
  getByCategory(categoryName) {
    return this.categories[categoryName]?.items || [];
  },

  /**
   * Get all category names
   */
  getCategoryNames() {
    return Object.keys(this.categories);
  },

  /**
   * Search items by name
   */
  search(query) {
    const lowerQuery = query.toLowerCase();
    return this.getAll().filter(
      (item) =>
        item.label.toLowerCase().includes(lowerQuery) || item.id.toLowerCase().includes(lowerQuery),
    );
  },
};

// Make available globally
if (typeof window !== 'undefined') {
  window.Items = Items;
}
